from django.apps import AppConfig


class MipetshopConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mipetshop'
